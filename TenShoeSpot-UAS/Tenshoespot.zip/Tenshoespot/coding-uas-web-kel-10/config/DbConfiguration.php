<?php
class DbConfiguration 
{
    public $conn;
    private $host = 'localhost';
    private $db_name = 'uas_web_db';
    private $username = 'root';
    private $password = '';

    public function __construct() {
        try {
            $dsn = "mysql:host=$this->host;dbname=$this->db_name";
            $conn = new PDO($dsn, $this->username, $this->password);

            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            $this->conn = $conn;
        } catch (PDOException $e) {
            echo "Koneksi gagal: " . $e->getMessage();
        }
    }
}