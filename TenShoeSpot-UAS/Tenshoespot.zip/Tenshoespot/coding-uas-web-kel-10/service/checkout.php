<?php
require_once '../config/DbConfiguration.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validasi dan ambil data dari request POST
    if (!isset($_POST['full_name'], $_POST['address'], $_POST['city'], $_POST['postal_code'], $_POST['phone'], $_POST['cart'])) {
        echo json_encode(['status' => 'error', 'message' => 'Missing required fields']);
        exit;
    }

    $fullName = $_POST['full_name'];
    $address = $_POST['address'];
    $city = $_POST['city'];
    $postalCode = $_POST['postal_code'];
    $phone = $_POST['phone'];
    $cart = json_decode($_POST['cart'], true); // Decode cart JSON ke array

    // Pastikan cart adalah array yang valid
    if (json_last_error() !== JSON_ERROR_NONE || !is_array($cart)) {
        echo json_encode(['status' => 'error', 'message' => 'Invalid cart data']);
        exit;
    }

    try {
        // Koneksi database
        $db = new DbConfiguration();
        $conn = $db->conn;

        // Pastikan koneksi berhasil
        if (!$conn) {
            throw new Exception('Database connection failed');
        }

        // Mulai transaksi
        $conn->beginTransaction();

        // Insert data customer
        $customerSql = "INSERT INTO customer (name, address, city, postal_code, phone) VALUES (:name, :address, :city, :postal_code, :phone)";
        $stmt = $conn->prepare($customerSql);
        $stmt->execute([
            ':name' => $fullName,
            ':address' => $address,
            ':city' => $city,
            ':postal_code' => $postalCode,
            ':phone' => $phone
        ]);
        $customerId = $conn->lastInsertId(); // Get the inserted customer ID

        // Prepare the product and transaction SQL queries
        $productSql = "INSERT INTO product (name, price, size, image, color, discount, brand) VALUES (:name, :price, :size, :image, :color, :discount, :brand)";
        $transactionSql = "INSERT INTO transaction (product_id, customer_id, quantity) VALUES (:product_id, :customer_id, :quantity)";
        
        foreach ($cart as $item) {
            // Pastikan item memiliki semua data yang dibutuhkan
            if (!isset($item['name'], $item['price'], $item['size'], $item['image'], $item['color'], $item['quantity'])) {
                throw new Exception('Invalid cart item data');
            }

            // Insert produk
            $stmt = $conn->prepare($productSql);
            $stmt->execute([
                ':name' => $item['name'],
                ':price' => $item['price'],
                ':size' => $item['size'],
                ':image' => $item['image'],
                ':color' => $item['color'],
                ':discount' => $item['discount'], // Ensure discount can be null
                ':brand' => $item['brand'] // Ensure brand can be null
            ]);
            $productId = $conn->lastInsertId(); // Get the inserted product ID

            // Insert transaksi
            $stmt = $conn->prepare($transactionSql);
            $stmt->execute([
                ':product_id' => $productId,
                ':customer_id' => $customerId,
                ':quantity' => $item['quantity']
            ]);
        }

        // Commit transaksi
        $conn->commit();
        echo json_encode(['status' => 'success', 'message' => 'Checkout berhasil']);
    } catch (Exception $e) {
        // Rollback jika terjadi kesalahan
        $conn->rollBack();
        echo json_encode(['status' => 'error', 'message' => 'Checkout gagal', 'error' => $e->getMessage()]);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request method']);
}
?>
