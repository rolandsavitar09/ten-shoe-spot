<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cart</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Michroma&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../styles/cart.style.css">
</head>
<body>
    <nav class="navbar">
        <div class="logo">
            <img src="../assets/logos/Logo 10 Shoe Spot.png" alt="Logo 10 Shoe Spot" style="width: 50px; height: auto;">
        </div>
        <div class="search-bar">
            <input type="text" placeholder="Search">
        </div>
        <ul class="nav-menu">
            <li><a href="man.php">Man</a></li>
            <li><a href="#">Women</a></li>
            <li><a href="#">Casual</a></li>
            <li><a href="#">Sport</a></li>
            <li><a href="#">Sneakers</a></li>
        </ul>
    </nav>

    <section class="breadcrumb">
        <a href="man.php"><img src="../assets/products/arrow.png" alt=""><span style="margin-left: 20px;">Back</span></a>
        <a href="cart.php" class="cart-icon">
          <div class="badge" id="cart-badge"></div>
          <img src="../assets/products/keranjang.png" alt="Cart" style="width: 30px; height: auto;">
        </a>
    </section>

    <div class="container">
        <div class="cart" id="cart-items">
            <!-- Cart items will be dynamically rendered here -->
        </div>
        <div class="summary">
            <div class="summary-header">Ringkasan Pesanan:</div>
            <div class="summary-item">
                <span id="total-products">0 Produk</span>
                <span id="total-price">Rp 0</span>
            </div>
            <div class="summary-item">
                <span>Pengiriman</span>
                <span>Gratis</span>
            </div>
            <div class="summary-item">
                <strong>Total (Termasuk Pajak)</strong>
                <strong id="grand-total">Rp 0</strong>
            </div>
            <div class="summary-item" id="discount-info" style="display: none;">
                <span>Diskon</span>
                <span id="discount-value">Rp 0</span>
            </div>
            <a href="co.php" class="checkout-btn">Checkout</a>
        </div>
    </div>
    <button onclick="clearCart()" style="margin-left: 40%; padding: 10px 100px; margin-bottom: 20px; cursor: pointer; background-color: #e53935; color: #fff; font-weight: bold; outline: none; border: none;">Hapus Semua</button>


    <footer>
        <section class="footer-info">
            <!-- Footer content -->
        </section>
    </footer>

    <script>
// set badge
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    document.getElementById('cart-badge').innerHTML = cart.length;
    if (cart.length > 0) {
        document.getElementById('cart-badge').style.display = "block";
    } else {
        document.getElementById('cart-badge').style.display = "none";
    }

    function renderCart() {
        const cart = JSON.parse(localStorage.getItem("cart")) || [];
        const cartContainer = document.getElementById("cart-items");
        const cartCount = document.getElementById("cart-badge");
        const totalProducts = document.getElementById("total-products");
        const totalPrice = document.getElementById("total-price");
        const grandTotal = document.getElementById("grand-total");
        const discountInfo = document.getElementById("discount-info");
        const discountValue = document.getElementById("discount-value");

        cartContainer.innerHTML = "";
        let total = 0;
        let discountAmount = 0;

        if (cart.length === 0) {
            cartContainer.innerHTML = "<p>Keranjang kosong.</p>";
            totalProducts.textContent = "0 Produk";
            totalPrice.textContent = "Rp 0";
            grandTotal.textContent = "Rp 0";
            cartCount.textContent = 0;
            discountInfo.style.display = "none";
            return;
        }

        cart.forEach(product => {
            total += product.price * product.quantity;

            // Calculate discount if available
            if (product.discount) {
                discountAmount += (product.price * product.discount / 100) * product.quantity;
            }

            const cartItem = document.createElement("div");
            cartItem.className = "cart-item";
            cartItem.innerHTML = `
                <img src="../assets/products/${product.image}" alt="${product.name}" style="width: 100px; height: auto;">
                <div class="cart-item-details">
                    <h4>${product.name}</h4>
                    <p>Harga: Rp ${product.price.toLocaleString()}</p>
                    
                    <p>Jumlah: ${product.quantity}</p>
                        <div style="display: flex; align-items: center; gap: 10px;">
                            <button style="width: 30px; height: 30px;" onclick="decreaseQty(${product.id})">-</button>
                            <button style="width: 30px; height: 30px;" onclick="increaseQty(${product.id})">+</button>
                        </div>
                </div>
                <button onclick="removeFromCart(${product.id})">Hapus</button>
            `;

            cartContainer.appendChild(cartItem);
        });

        cartCount.textContent = cart.length;
        totalProducts.textContent = `${cart.length} Produk`;
        totalPrice.textContent = `Rp ${total.toLocaleString()}`;
        grandTotal.textContent = `Rp ${(total - discountAmount).toLocaleString()}`;

        // Show discount info if applicable
        if (discountAmount > 0) {
            discountInfo.style.display = "block";
            discountValue.textContent = `Rp ${discountAmount.toLocaleString()}`;
        } else {
            discountInfo.style.display = "none";
        }
    }

    function removeFromCart(productId) {
        let cart = JSON.parse(localStorage.getItem("cart")) || [];
        cart = cart.filter(product => product.id !== productId);
        localStorage.setItem("cart", JSON.stringify(cart));
        renderCart();
        // update badge
        document.getElementById('cart-badge').innerHTML = cart.length;
        if (cart.length > 0) {
            document.getElementById('cart-badge').style.display = "block";
        } else {
            document.getElementById('cart-badge').style.display = "none";
        }
    }

    function clearCart() {
        localStorage.removeItem("cart");
        document.getElementById('cart-badge').style.display = "none";
        renderCart();
    }

    function increaseQty(productId) {
        let cart = JSON.parse(localStorage.getItem("cart")) || [];
        cart = cart.map(product => {
            if (product.id === productId) {
                product.quantity += 1; // Tambahkan jumlah produk
            }
            return product;
        });
        localStorage.setItem("cart", JSON.stringify(cart));
        renderCart(); // Render ulang keranjang
    }

    function decreaseQty(productId) {
        let cart = JSON.parse(localStorage.getItem("cart")) || [];
        cart = cart.map(product => {
            if (product.id === productId) {
                product.quantity -= 1; // Kurangi jumlah produk
            }
            return product;
        }).filter(product => product.quantity > 0); // Hapus produk dengan jumlah 0

        localStorage.setItem("cart", JSON.stringify(cart));
        if (cart.length === 0) {
            document.getElementById('cart-badge').style.display = "none";
        }
        renderCart(); // Render ulang keranjang
    }        

    renderCart();
    </script>
</body>
</html>