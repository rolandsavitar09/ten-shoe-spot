<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Catalogue</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Michroma&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../../styles/detail.style.css">
</head>
<body>

    <nav class="navbar">
        <div class="logo">
            <img src="../../assets/logos/Logo 10 Shoe Spot.png" alt="Logo 10 Shoe Spot" style="width: 50px; height: auto;">
        </div>
        <div class="search-bar">
            <input type="text" placeholder="Search">
        </div>
        <ul class="nav-menu">
            <li><a href="/coding-uas-web-kel-10/pages/man.php">Man</a></li>
            <li><a href="#">Women</a></li>
            <li><a href="#">Casual</a></li>
            <li><a href="#">Sport</a></li>
            <li><a href="#">Sneakers</a></li>
        </ul>
    </nav>

    <section class="breadcrumb">
        <a href="/tenshoespot/coding-uas-web-kel-10/pages/man.php"><img src="../../assets/products/arrow.png" alt=""><span style="margin-left: 20px;">Back</span></a>
    </section>

    <main>
        <div class="product-container">
            <div class="product-image">
                <img src="../../assets/products/product1.png" alt="Adidas Spezial">
            </div>
            <div class="product-details">
                <h1>Adidas Spezial</h1>
                <p class="product-color">Brown</p>
                <p class="product-price">Rp 1.700.000</p>
                <label for="size">Pilih Size:</label>
                <select id="size" class="size-selector">
                    <option value="38">38</option>
                    <option value="39">39</option>
                    <option value="40" selected>40</option>
                    <option value="41">41</option>
                    <option value="42">42</option>
                    <option value="43">43</option>
                </select>
                <button class="add-to-cart buy-now" onclick="checkoutProduct()">Beli Sekarang</button>
                <button class="add-to-cart add-to-cart-button" onclick="addToCartFromDetails()">Tambah ke Keranjang</button>

                <p class="product-description">
                    Adidas Spezial adalah sepatu ikonik yang memadukan gaya klasik dengan kenyamanan modern, dirancang untuk para pencinta streetwear dan olahraga. Dibuat dari bahan berkualitas tinggi dengan detail yang elegan, sepatu ini menawarkan tampilan vintage yang tak lekang oleh waktu, sekaligus memberikan dukungan optimal untuk aktivitas sehari-hari.
                </p>
            </div>
        </div>
    </main>

    <footer>
        <section class="footer-info">
            <div class="column">
                <h3>Get the Latest Collection of Sports Shoes, Sneakers, and Casual Shoes at Ten Shoe Spot</h3>
                <p>Welcome to Ten Shoe Spot...</p>
            </div>
            <div class="column">
                <h3>Ten Shoe Spot Provides All Your Footwear Needs</h3>
                <p>Looking for comfortable shoes...</p>
            </div>
        </section>
        <section class="email-signup">
            <input type="email" placeholder="REGISTER YOUR EMAIL TO GET INFO AND SPECIAL OFFERS">
            <button>SIGN UP FOR FREE</button>
        </section>
        <section class="footer-nav">
            <div>
                <h4>PRODUCT</h4>
                <ul>
                    <li><a href="#">Shoe</a></li>
                </ul>
            </div>
            <div>
                <h4>HELP</h4>
                <ul>
                    <li><a href="#">Get help</a></li>
                    <li><a href="#">Order Status</a></li>
                    <li><a href="#">Delivery</a></li>
                    <li><a href="#">Returns</a></li>
                    <li><a href="#">Payment Option</a></li>
                    <li><a href="#">Contact Us</a></li>
                </ul>
            </div>
            <div>
                <h4>COMPANY</h4>
                <ul>
                    <li><a href="#">About Ten Shoe Spot</a></li>
                </ul>
            </div>
        </section>
        <div class="copyright">
            <p>2024 Ten Shoe Spot. All Rights Reserved.</p>
        </div>
    </footer>

    <script>
        const product = {
            id: 1,
            name: "Adidas Spezial",
            price: 1700000,
            description: "Adidas Spezial adalah sepatu ikonik yang memadukan gaya klasik dengan kenyamanan modern.",
            image: "product1.png",
            color: "Brown",
            sizes: [38, 39, 40, 41, 42, 43],
            discount: "10",
            brand: "Adidas"
        };

        const cartBadge = document.getElementById('cart-badge');
        let cart = JSON.parse(localStorage.getItem('cart')) || [];

        function addToCart(product) {
            const existingProductIndex = cart.findIndex(item => item.id === product.id);

            if (existingProductIndex !== -1) {
                cart[existingProductIndex].quantity += 1;
            } else {
                cart.push({ ...product, quantity: 1 });
            }

            localStorage.setItem('cart', JSON.stringify(cart));
        }

        function checkoutProduct() {
            const selectedSize = document.getElementById("size").value;
            const productWithSize = { ...product, size: selectedSize };
            addToCart(productWithSize);
            window.location.href = "/tenshoespot/coding-uas-web-kel-10/pages/co.php";
        }

        function addToCartFromDetails() {
            const selectedSize = document.getElementById("size").value;
            const productWithSize = { ...product, size: selectedSize };
            addToCart(productWithSize);
            window.location.href = "/tenshoespot/coding-uas-web-kel-10/pages/cart.php";
        }

        window.onload = updateCartCount;
    </script>

</body>
</html>
