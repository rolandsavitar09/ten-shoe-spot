<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout - Ten Shoe Spot</title>
    <link rel="stylesheet" href="../styles/co.style.css">
</head>
<body>

    <nav class="navbar">
        <div class="logo">
            <img src="../assets/logos/Logo 10 Shoe Spot.png" alt="Logo Ten Shoe Spot" style="width: 50px; height: auto;">
        </div>
        <div class="nav-menu">
            <a href="/tenshoespot/coding-uas-web-kel-10/index.php">Home</a>
            <a href="man.php">Products</a>
            <a href="cart.php">Cart</a>
        </div>
    </nav>

    <main class="checkout-container">
        <section class="order-summary">
            <h2>Order Summary</h2>
            <div id="cart-items">
                <!-- Cart items will be rendered here -->
            </div>
            <div class="total">
                <p>Total: <span id="total-price">Rp 0</span></p>
            </div>
        </section>

        <section class="shipping-details">
            <h2>Shipping Details</h2>
            <form action="" id="shipping-form" method="POST">
                <label for="full-name">Full Name</label>
                <input type="text" id="full-name" placeholder="Your Name" required>
                
                <label for="address">Shipping Address</label>
                <input type="text" id="address" placeholder="Your Address" required>

                <label for="city">City</label>
                <input type="text" id="city" placeholder="City" required>

                <label for="postal-code">Postal Code</label>
                <input type="text" id="postal-code" placeholder="Postal Code" required>

                <label for="phone">Phone Number</label>
                <input type="text" id="phone" placeholder="Phone Number" required>

                <h3>Select Payment Method</h3>
                <label for="payment-method">Payment Method</label>
                <select id="payment-method" required>
                    <option value="credit-card">Credit Card</option>
                    <option value="bank-transfer">Bank Transfer</option>
                    <option value="paypal">PayPal</option>
                </select>

                <button type="submit" id="checkout-btn">Proceed to Payment</button>
            </form>
        </section>
    </main>

    <footer>
        <p>&copy; 2024 Ten Shoe Spot. All Rights Reserved.</p>
    </footer>

    <script>
      document.getElementById("shipping-form").addEventListener("submit", function (event) {
        event.preventDefault(); // Mencegah form refresh halaman

        const cart = JSON.parse(localStorage.getItem("cart"));

        const fullName = document.getElementById("full-name").value;
        const address = document.getElementById("address").value;
        const city = document.getElementById("city").value;
        const postalCode = document.getElementById("postal-code").value;
        const phone = document.getElementById("phone").value;

        fetch("../service/checkout.php", {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: new URLSearchParams({
                full_name: fullName,
                address: address,
                city: city,
                postal_code: postalCode,
                phone: phone,
                cart: JSON.stringify(cart)
            })
        })
        .then(response => response.json())
        .then(data => {
          console.log("data ", data);
          
            if (data.status === "success") {
                alert("Checkout berhasil!");
                localStorage.removeItem("cart"); // Hapus keranjang setelah checkout berhasil
                window.location.href = "/coding-uas-web-kel-10"; // Redirect ke halaman utama
            } else {
                alert("Checkout gagal: " + data.message);
            }
        })
        .catch(error => {
            console.error("Error:", error);
            alert("Terjadi kesalahan saat checkout.");
        });
    });

    function renderCart() {
    const cart = JSON.parse(localStorage.getItem("cart")) || [];
    const cartItemsContainer = document.getElementById("cart-items");
    const totalPriceElement = document.getElementById("total-price");

    cartItemsContainer.innerHTML = "";
    let total = 0;

    if (cart.length === 0) {
        cartItemsContainer.innerHTML = "<p>Your cart is empty.</p>";
        totalPriceElement.textContent = "Rp 0";
        return;
    }

    cart.forEach(product => {
        // Get the discount value if available (assuming it's a percentage discount stored in the product object)
        const discount = product.discount ? parseFloat(product.discount) : 0;
        const priceAfterDiscount = product.price * (1 - discount / 100);

        total += priceAfterDiscount * product.quantity;

        const cartItem = document.createElement("div");
        cartItem.className = "product";
        cartItem.innerHTML = `
            <img src="../assets/products/${product.image}" alt="${product.name}" class="product-image">
            <div class="product-details">
                <p>${product.name}</p>
                <p>Size: ${product.size || "N/A"} | Color: ${product.color || "N/A"}</p>
                <p>Rp ${priceAfterDiscount.toLocaleString()} x ${product.quantity}</p>
            </div>
        `;
        cartItemsContainer.appendChild(cartItem);
    });

    totalPriceElement.textContent = `Rp ${total.toLocaleString()}`;
}


        // Render cart items on page load
        renderCart();
    </script>
</body>
</html>
