<?php
require './config/DbConfiguration.php';

$connect = new DbConfiguration();
$connect->conn;
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>E-Commerce Sepatu</title>
    <link href="https://fonts.googleapis.com/css2?family=Michroma&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="./styles/homePage.style.css">
</head>

<body>
    <!-- Header -->
<header>
    <img src="./assets/logos/Logo 10 Shoe Spot.png" alt="Logo 10 Shoe Spot" style="width: 50px; height: auto;">
    <nav>
        <a href="pages/man.php">Man</a>
        <a href="#">Women</a>
        <a href="#">Casuals</a>
        <a href="#">Sport</a>
        <a href="#">Sneakers</a>
    </nav>
</header>

<!-- Hero Section with 2 Slides -->
<section class="hero">
    <div class="hero-content">
        <h1>
            <span>NEW ARRIVAL</span>
            <span class="line">TEN SHOE SPOT</span>
        </h1>
        <a href="pages/man.php">
            <button>SHOP NOW</button>
        </a>
        <p class="website-text">www.tenshoespot.com</p>
    </div>
</section>


    <!-- BEST SELLER Text -->
    <div class="best-seller">BEST SELLER</div>

    <!-- Product Section -->
    <section class="products">
        <div class="product">
            <img src="assets/products/Adidas Spezial Navy.png" alt="Product 1">
            <h2>Adidas - Navy</h2>
            <p>Rp 1,700,000</p>
        </div>
        <div class="product">
            <img src="assets/products/Adidas Putih.png" alt="Product 2">
            <h2>Adidas - White</h2>
            <p>Rp 1,700,000</p>
        </div>
        <div class="product">
            <img src="assets/products/Ortuseight.png" alt="Product 3">
            <h2>Ortuseight - Blue</h2>
            <p>Rp 350,000</p>
        </div>
        <div class="product">
            <img src="assets/products/Sepatu Putih.png" alt="Product 4">
            <h2>Haifers - White</h2>
            <p>Rp 429,000</p>
        </div>
    </section>

    <!-- Promo Section -->
    <section class="promo-section">
        <div class="promo">
            <img src="assets/products/New Sneakers.png" alt="Promo 1">
            <h2>New Sneakers</h2>
            <p>Style terbaru untuk Anda</p>
        </div>
        <div class="promo">
            <img src="assets/products/Coming Soon.png" alt="Promo 2">
            <h2>Coming Soon</h2>
            <p>Produk akan segera rilis</p>
        </div>
        <div class="promo">
            <img src="assets/products/Diskon.png" alt="Promo 3">
            <h2>Discount</h2>
            <p>Dapatkan diskon spesial</p>
        </div>
    </section>

    <!-- Footer -->
    <footer>
        <p>&copy; 2024 Ten Shoe Spot. All Rights Reserved.</p>
    </footer>
</body>

</html>